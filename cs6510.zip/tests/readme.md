# Ops Tests

## To run ops tests simpy run the program i.e. `python test.py`. Terminal will display if tests passed.
