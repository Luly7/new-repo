class Modes:
    def run(self):
        raise NotImplementedError("Each mode must implement its own run method")